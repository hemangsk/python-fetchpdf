from .fetchpdf import main
main()
